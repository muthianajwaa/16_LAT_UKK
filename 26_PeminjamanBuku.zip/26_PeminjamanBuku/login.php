<?php
include "koneksi.php";

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $query = mysqli_query($conn, "SELECT * FROM user WHERE username='$username' AND password='$password'");
    $data = mysqli_fetch_assoc($query);

    if ($data) {
        $_SESSION['id'] = $data['id'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['level'] = $data['level'];

        header("Location: index.php");
        exit;
    } else {
        $pesan = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
<h2>APLIKASI PEMINJAMAN BUKU</h2>
<?php if (isset($pesan)) echo $pesan; ?>
<form method="post">
    Username<br>
    <input type="text" name="username" required><br><br>
    Password<br>
    <input type="password" name="password" required><br><br>
    <button type="submit" name="login">Login</button>
</form>
</body>
</html>