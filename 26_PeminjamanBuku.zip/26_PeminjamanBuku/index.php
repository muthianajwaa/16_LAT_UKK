<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
} elseif ($_SESSION['level'] == "admin") {
    header("Location: admin/dashboard.php");
} else {
    header("Location: user/dashboard.php");
}
exit;
?>